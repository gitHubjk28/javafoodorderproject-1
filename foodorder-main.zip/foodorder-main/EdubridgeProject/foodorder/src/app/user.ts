export class User {
    userId!:string;
    name!:string;
    phone!:string;
    email!:string;
    password!:string;
}
