export class Users {
    userId!:string;
    password!:string;
}
